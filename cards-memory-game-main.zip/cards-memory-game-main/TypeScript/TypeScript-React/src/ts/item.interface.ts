export interface Item {
  name: string 
  image: string
}