# Memory Card game

This is the version of the game in TypeScript.

## TypeScript

PR's are welcome

Please check the [contribution.md](https://github.com/GeraAlcantara/cards-memory-game/blob/main/CONTRIBUTING.md)
