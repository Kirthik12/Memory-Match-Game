# Non Code Contributions

Before to add your contribution please read the examples in [this file](https://github.com/GeraAlcantara/cards-memory-game/blob/main/NON_CODE_CONTRIBUTIONS/EXAMPLES.md)

## Social post

## QA Reviews

## Blog Posts

## Design
