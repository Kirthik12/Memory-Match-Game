# Examples

To add your non code contribution to this project please follow the one of the next examples

## Social post

### Contributor name: name_user

- Title: Post title
- Link to post: [post](https://github.com/)

## QA Reviews

### Contributor name: name_user

- Title issue: Issue title
- Link to issue: [issue](https://github.com/)

## Blog Posts

### Contributor name: name_user

- Title: Blog Post title
- Link to blog post: [post](https://github.com/)

## Design

### Contributor name: name_user

- Description resource: Resource of type...
- Link to resource: [resource](https://github.com/)
