# Memory Card game

This is the version of the game in Svelte.

## Svelte

PR's are welcome

<!-- TODO: contribution.md link  -->

Please check the [contribution.md](https://github.com/GeraAlcantara/cards-memory-game/blob/main/CONTRIBUTING.md)
