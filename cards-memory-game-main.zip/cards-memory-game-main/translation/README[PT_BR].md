# Cards-Memory-Game

Jogo da memória clássico: vire a carta e encontre os pares em Vanilla JavaScript, Svelte, VUE, React

## O jogo vai ser recriado nas seguintes bibliotecas JavaScript

- React
- VUE
- Svelte

### Prévia

![Memorie Game Example](https://github.com/GeraAlcantara/cards-memory-game/blob/main/img/gameExample.gif?raw=true)

 Você pode encontrar o jogo na pasta gameBase
 Por favor reveja antes de tentar implementar qualquer biblioteca

Veja como [contribuir](https://github.com/GeraAlcantara/cards-memory-game/blob/main/CONTRIBUTING.md)
